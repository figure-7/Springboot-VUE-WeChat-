<template>
	<view>
		<view class="search-container">
			<image src="../../static/img/logo-small.jpg" class="logo" mode="widthFix"></image>
			<view class="search-bar">
				<icon type="search" size="16" class="search-icon"></icon>
				<input type="text" placeholder="请输入关键字" class="search" />
			</view>
		</view>
		<swiper :autoplay="true" :interval="5000" :druation="1000" :indicator-dots="true" class="swiper-container">
			<swiper-item v-for="one in topList" :key="one.id">
				<image :src="one.banner" mode="widthFix" class="swiper-image"></image>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				"topList":[]
			}
		},
		methods:{
			
		},
		onShow:function(){
			let that=this
			uni.request({
				url:that.url.searchTop,
				method:"GET",
				header:{
					"token":uni.getStorageSync("token")
				},
				success:function(resp){
					console.log(resp.data.result)
					let list = resp.data.result
					for(let one of list){
						one.banner = that.url.img + "/" + one.banner
					}
					that.topList = list
				}
			})
		}
	}
</script>

<style lang="less">
	@import url("index.less");
</style>
