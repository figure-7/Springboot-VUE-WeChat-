import Vue from 'vue'
import App from './App'

Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
    ...App
})
app.$mount()
let baseUrl="http://localhost:8080/renren-fast"
Vue.prototype.url={
	"img":"http://localhost",
	"login":baseUrl + "/app/user/login",
	"searchTop":baseUrl + "/app/curriculum/searchTop"
}